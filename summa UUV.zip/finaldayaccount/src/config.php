<?php
session_start();
$conn = mysqli_connect("db", "root", "yourpassword", "reglog");
?>